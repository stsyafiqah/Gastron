
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="50x50" href="<?php echo base_url(); ?>asset/assets/images/gastron.png">
    <title>Gastron</title>
    <!-- Bootstrap Core CSS -->
    <link href="<?php echo base_url(); ?>asset/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo base_url(); ?>asset/css/style.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="<?php echo base_url(); ?>asset/css/colors/default.css" id="theme" rel="stylesheet">

     <!-- DataTables CSS -->
    <link href="<?php echo base_url(); ?>vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php echo base_url(); ?>vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">
    
    <!--<link href="<?php echo base_url(); ?>asset_signature/css/jquery.signaturepad.css" rel="stylesheet">-->

    <link href="<?php echo base_url(); ?>dist/sweetalert.css" rel="stylesheet">
		
<!--	<link href="<?php echo base_url(); ?>asset_signature/docs/signature-pad.css" rel="stylesheet">	
		<script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-39365077-1']);
    _gaq.push(['_trackPageview']);

    (function() {
      var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
      ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();
  </script>-->
<style>
  
    
    <style>
    .dropdown-toggle[aria-expanded="false"]:after {
  transform: rotate(270deg);
}


/*for the animation*/
.dropdown-toggle:after {
  transition: 0.5s;
}
    
    </style>
